import axios from 'axios';
import React, { useEffect, useState } from 'react';

 const RoleList = () => { // RoleList>>>>(filename)
 
  const [roles, setRoles] = useState([]); // roles>>>>(folder)

  useEffect(() => {
    axios({
      url: "https://jsonplaceholder.typicode.com/users",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data);
        setRoles(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
      <h1 className="text-center my-4">Roles List</h1>
      <div className="container">
        <table className="table table-bordered table-striped">
          <thead className="table-dark">
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Username</th>
              <th scope="col">Email</th>
              <th scope="col">Address</th>
            </tr>
          </thead>
          <tbody>
            {roles.map((role, index) => (   // roles>>>>(folder)
              <tr key={role.id}>
                <th scope="row">{index + 1}</th>
                <td>{role.name}</td>
                <td>{role.username}</td>
                <td>{role.email}</td>
                <td>
                  {role.address
                    ? `${role.address.street}, ${role.address.city}`
                    : "N/A"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default RoleList;

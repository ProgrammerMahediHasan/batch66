import React from 'react'

const EditList = () => {
  return (
    <div>EditList</div>
  )
}

export default EditList
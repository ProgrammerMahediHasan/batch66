import React from 'react'

const CreateRole = () => {
  return (
    <div><h1>CreateRole</h1></div>
  )
}

export default CreateRole
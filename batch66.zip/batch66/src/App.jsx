import { useState } from 'react'
import Layout from './Layout/Layout'

import CreateRole from './pages/roles/CreateRole'
import EditList from './pages/roles/EditList'
import RoleList from './pages/roles/RoleList'
import { BrowserRouter, Route, Routes } from 'react-router-dom'



function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     
<BrowserRouter>

      <Routes>
        <Route path="/" element={<Layout />} />

        <Route path="/roles" element={<RoleList />} />
        <Route path="/createrole" element={<CreateRole />} />
        <Route path="/editlist" element={<EditList />} />

      </Routes>
    </BrowserRouter>

    </>
  )
}

export default App

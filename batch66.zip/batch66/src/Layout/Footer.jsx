import React from 'react'

const Footer = () => {
  return (
    <>
    <footer class="bg-dark text-white text-center py-3 mt-5">
  <p class="mb-0">© 2025 Your Company. All rights reserved.</p>
</footer>

    </>
  )
}

export default Footer